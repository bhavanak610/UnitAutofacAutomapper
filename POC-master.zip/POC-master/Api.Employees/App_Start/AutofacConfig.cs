﻿using Api.Employees.Mappings;
using Autofac;
using Autofac.Integration.WebApi;
using AutoMapper;
using BAL.Employees;
using Database.Employees;
using Database.Employees.DataAccess.Repository;
using Database.Employees.DataAccess.UnitOfWork;
using System.Reflection;
using System.Web.Http;

namespace Api.Employees.App_Start
{
    /// <summary>
    /// Dependency configuration 
    /// </summary>
    public  static class AutofacConfig
    {
        /// <summary>
        /// All the dependency mapping definitions
        /// </summary>
        public static void AutofacConfigRegister()
        {
            var builder = new ContainerBuilder();
            var config = GlobalConfiguration.Configuration;
                
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());


            builder.RegisterType<DepartmentRepository>().As<IDepartmentRepository>().InstancePerLifetimeScope();
            builder.RegisterType<DocumentTypeRepository>().As<IDocumentTypeRepository>().InstancePerLifetimeScope();
            builder.RegisterType<EmployeeRepository>().As<IEmployeeRepository>().InstancePerLifetimeScope();

            builder.RegisterType<DepartmentUnitOfWork>().As<IDepartmentUnitOfWork>().InstancePerLifetimeScope();
            builder.RegisterType<DocumentUnitOfWork>().As<IDocumentUnitOfWork>().InstancePerLifetimeScope();
            builder.RegisterType<EmployeeUnitOfWork>().As<IEmployeeUnitOfWork>().InstancePerLifetimeScope();

            builder.RegisterType<EmployeeCordinator>().As<IEmployeeCordinator>().InstancePerLifetimeScope();
            builder.RegisterType<EmployeeContext>().InstancePerLifetimeScope();

            builder.RegisterInstance(AutoMapperConfiguration.RegisterAutoMapper()).As<IMapper>().SingleInstance();
            
            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
            
        }
    }
}