﻿using AutoMapper;
using BAL.Employees;
using Contract.Employee;
using System.Collections.Generic;
using System.Web.Http;

namespace Api.Employees.Controllers
{
    /// <summary>
    /// Employee Controller to open the api service call
    /// </summary>
    public class EmployessController : ApiController
    {
        /// <summary>
        /// Employee Cordinator refernce
        /// </summary>
        private readonly IEmployeeCordinator empCordinator;

        /// <summary>
        /// Mapper Reference
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// instialiaze controller context with employee Cordinator
        /// </summary>
        /// <param name="empCordinator"></param>        
        public EmployessController(IEmployeeCordinator empCordinator, IMapper mapper)
        {
            this.empCordinator = empCordinator;
            this.mapper = mapper;

        }
        /// <summary>
        /// Returns  all the Employees Details
        /// </summary>
        /// <returns></returns>
        [Route("Employees")]
        [HttpGet]
        public IHttpActionResult GetEmployees()
        {
            var employeeList = empCordinator.GetEmployee();
            var result = mapper.Map<IEnumerable<EmployeeResponse>>(employeeList);
            return Ok(result);
        }
        /// <summary>
        /// Returns employee details of specific id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("Employee/{id}")]
        [HttpGet]
        public IHttpActionResult GetEmployeeDetails(int id)
        {
            var employeeDetails = empCordinator.GetEmployeeById(id);
            var result = mapper.Map<EmployeeDetailResponse>(employeeDetails);
            return Ok(result);

        }
        /// <summary>
        /// Add or Update the employee details
        /// </summary>
        /// <param name="id"></param>
        /// <param name="employee"></param>
        /// <returns></returns>
        [Route("EmployeePost")]
        [HttpPost]
        public IHttpActionResult SaveEmployee([FromBody] EmployeeResponse employee)
        {
            if (employee != null)
            {
                var employeeModel = mapper.Map<ModelEmployee.EmployeeModel>(employee);
                var modalsaved = empCordinator.SaveEmployeee(employeeModel);
                return Ok(modalsaved);
            }
            else
            {
                return BadRequest(ModelState);
            }

        }
        /// <summary>
        /// Deletes the employee details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("Employee/deactivate/{id}")]
        [HttpPost]
        public IHttpActionResult DeleteEmployees(int id)
        {
            var isDeactivated = empCordinator.DeleteEmployee(id);
            return Ok(isDeactivated);
        }
    }
}
