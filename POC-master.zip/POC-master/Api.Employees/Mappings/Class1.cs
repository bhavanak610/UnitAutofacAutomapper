﻿using AutoMapper;
using Contract.Employee;
using ModelEmployee;
/// <summary>
/// Profile class to map model to contract
/// </summary>
public class EmployeeModelContractProfile : Profile
{
    /// <summary>
    /// Create map for modal to response modal
    /// </summary>
    public EmployeeModelContractProfile()
    {
        CreateMap<DepartmentModel, DepartmentResponse>();
        CreateMap<DocumentModel, DocumentResponse>();
        CreateMap<EmployeeModel, EmployeeResponse>()
            .ForMember(d => d.GradeStar, o => o.MapFrom(sourceMember => sourceMember.Salary > 10000 ? Grade.star3 : Grade.star2));
        CreateMap<EmployeeDetailModal, EmployeeDetailResponse>();
    }
}