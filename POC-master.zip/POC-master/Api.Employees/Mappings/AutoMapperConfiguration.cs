﻿using AutoMapper;
using BAL.Employees.Mapping;
using Contract.Employee;
using ModelEmployee;

namespace Api.Employees.Mappings
{
    /// <summary>
    /// Configure Mapper
    /// </summary>
    public static class AutoMapperConfiguration
    {/// <summary>
     /// Mapper Configuration to Add All the Profile to mapper
     /// </summary>
     /// <returns></returns>
        public static IMapper RegisterAutoMapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<EmployeeModelContractProfile>();
                cfg.AddProfile<EmployeeContractModelProfile>();
                cfg.AddProfile<EmployeeModelEntitiesProfile>();
                cfg.AddProfile<EmployeeEntitiesModelProfile>();
                // Add all your profiles
            });
            var mapper = config.CreateMapper();
            return mapper;
        }
        /// <summary>
        /// Profile class to map model to contract
        /// </summary>
        public class EmployeeContractModelProfile : Profile
        {
            /// <summary>
            /// Create map for modal to response modal
            /// </summary>
            public EmployeeContractModelProfile()
            {
                CreateMap<DepartmentResponse, DepartmentModel>();
                CreateMap<DocumentResponse, DocumentModel>();
                CreateMap<EmployeeResponse, EmployeeModel>()
                 .ForMember(d => d.DepartmentId, o => o.MapFrom(sourceMember => sourceMember.Departments.DepartmentId))
                 .ForMember(d => d.DocumentTypeId, o => o.MapFrom(sourceMember => sourceMember.Documents.DocumentTypeId));
                CreateMap<EmployeeDetailResponse, EmployeeDetailModal>();

            }
        }

    }
}
