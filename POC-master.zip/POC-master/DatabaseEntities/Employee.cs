﻿namespace DatabaseEntities
{
    /// <summary>
    /// Maps to all the emplyee dependencies and column of EmployeeTables
    /// </summary>
    public class Employee
    {
        /// <summary>
        /// Unique Identity for Employee
        /// </summary>
        public int EmployeeId { get; set; }
        /// <summary>
        /// Describe Employee by Name
        /// </summary>
        public string EmployeeName { get; set; }
        /// <summary>
        /// Pan number of Employee
        /// </summary>
        public string PAN { get; set; }
        /// <summary>
        /// Adhhar number of Employee
        /// </summary>
        public string AddharNo { get; set; }
        /// <summary>
        /// Salary of Employee
        /// </summary>
        public decimal Salary { get; set; }
        /// <summary>
        /// DepartmentId foreignkey to map with Department table
        /// </summary>
        public int DepartmentId { get; set; }
        /// <summary>
        /// DocumentTypeId foreignkey to map with DeocumentType table
        /// </summary>
        public int DocumentTypeId { get; set; }
        /// <summary>
        /// Foreign Key referenced objects
        /// </summary>
        public  Department Departments { get; set; }
        /// <summary>
        /// Foreign Key referenced objects
        /// </summary>
        public  DocumentType Documents { get; set; }
    }
}
