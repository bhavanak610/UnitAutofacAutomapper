﻿namespace DatabaseEntities
{
    /// <summary>
    /// Maps with table Department
    /// </summary>
    public class Department
    {
        /// <summary>
        ///Unique idendity of department
        /// </summary>
        public int DepartmentId { get; set; }
        /// <summary>
        /// Dercibes the Department by name
        /// </summary>
        public string DepartmentName { get; set; }            
       
    }
}
