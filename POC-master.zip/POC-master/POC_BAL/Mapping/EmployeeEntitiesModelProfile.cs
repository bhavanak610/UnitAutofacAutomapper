﻿using AutoMapper;
using DatabaseEntities;
using ModelEmployee;

namespace BAL.Employees.Mapping
{
    /// <summary>
    /// Mapping from Databse Entities to BAL model
    /// </summary>
    public class EmployeeEntitiesModelProfile : Profile
    {
        /// <summary>
        /// To configure the created map
        /// </summary>
        public EmployeeEntitiesModelProfile()
        {
            CreateMap<Department, DepartmentModel>();
            CreateMap<DocumentType, DocumentModel>();
            CreateMap<Employee, EmployeeModel>();
        }
    }

}