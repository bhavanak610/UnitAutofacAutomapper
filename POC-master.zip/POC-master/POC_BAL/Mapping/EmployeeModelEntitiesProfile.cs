﻿using AutoMapper;
using DatabaseEntities;
using ModelEmployee;

namespace BAL.Employees.Mapping
{
    /// <summary>
    /// Mapping from Databse Entities to BAL model
    /// </summary>
    public class EmployeeModelEntitiesProfile : Profile
    {
        /// <summary>
        /// To configure the created map
        /// </summary>
        public EmployeeModelEntitiesProfile()
        {
            CreateMap<DepartmentModel, Department>();
            CreateMap<DocumentModel, DocumentType>();
            CreateMap<EmployeeModel, Employee>();
        }
    }

}