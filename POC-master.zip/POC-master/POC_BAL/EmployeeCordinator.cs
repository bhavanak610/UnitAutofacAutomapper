﻿using AutoMapper;
using Database.Employees.DataAccess.UnitOfWork;
using ModelEmployee;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BAL.Employees
{
    /// <summary>
    /// To Co-ordinate with Controller and unit of work
    /// </summary>
    public class EmployeeCordinator : IEmployeeCordinator
    {
        /// <summary>
        /// Employee Unit of work reference 
        /// </summary>
        private readonly IEmployeeUnitOfWork employeeUnit;

        /// <summary>
        /// Department Unit of work reference 
        /// </summary>
        private readonly IDepartmentUnitOfWork departmentUnit;

        /// <summary>
        /// Document Unit of work reference 
        /// </summary>
        private readonly IDocumentUnitOfWork documentUnit;

        /// <summary>
        /// Instatiate all the related unit of work Employee,Department,Document
        /// </summary>
        /// <param name="employeeUnit"></param>
        /// <param name="departmentUnit"></param>
        /// <param name="documentUnit"></param>
        public EmployeeCordinator(IEmployeeUnitOfWork employeeUnit, IDepartmentUnitOfWork departmentUnit, IDocumentUnitOfWork documentUnit)
        {
            this.employeeUnit = employeeUnit;
            this.departmentUnit = departmentUnit;
            this.documentUnit = documentUnit;
        }

        /// <summary>
        /// Gets all the Employee details
        /// </summary>
        /// <returns></returns>
        public IEnumerable<EmployeeModel> GetEmployee()
        {
            return employeeUnit.GetEmployee().ToList();
        }

        /// <summary>
        /// Gets all the Documents details
        /// </summary>
        /// <returns></returns>
        public IEnumerable<DocumentModel> GetDocuments()
        {
            var documents = documentUnit.GetDocuments().ToList();
            return (documents);
        }

        /// <summary>
        /// Gets all the Departments details
        /// </summary>
        /// <returns></returns>
        public IEnumerable<DepartmentModel> GetDepartments()
        {
            var departments = departmentUnit.GetDepartment().ToList();
            return (departments);
        }

        /// <summary>
        /// Gets detail of Specific employee by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public EmployeeDetailModal GetEmployeeById(int id)
        {
            return new EmployeeDetailModal
            {
                employeeModel = employeeUnit.GetEmployeeById(id),
                DepartmentList = departmentUnit.GetDepartment(),
                DocumentList = documentUnit.GetDocuments(),
            };
        }

        /// <summary>
        /// Insert the new employee 
        /// </summary>
        /// <param name="NewEmployee"></param>
        /// <returns></returns>
        public EmployeeModel SaveEmployeee(EmployeeModel newEmployee)
        {
            newEmployee.Departments = null;
            newEmployee.Documents = null;
            var result = employeeUnit.SaveEmployeee(newEmployee);
            return result;
        }        
        /// <summary>
        /// Delete the Emplyee details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeleteEmployee(int id)
        {
            try
            {
                employeeUnit.DeleteEmployee(id);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

    }
}
