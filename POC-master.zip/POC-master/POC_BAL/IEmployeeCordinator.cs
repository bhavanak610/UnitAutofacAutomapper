﻿using ModelEmployee;
using System.Collections.Generic;

namespace BAL.Employees
{
    /// <summary>
    /// Operation for Employees
    /// </summary>
    public interface IEmployeeCordinator
    {
        /// <summary>
        /// Gets all the Employee details
        /// </summary>
        /// <returns></returns>
        IEnumerable<EmployeeModel> GetEmployee();
        /// <summary>
        /// Gets all the Documents details
        /// </summary>
        /// <returns></returns>
        IEnumerable<DocumentModel> GetDocuments();
        /// <summary>
        /// Gets all the Departments details
        /// </summary>
        /// <returns></returns>
        IEnumerable<DepartmentModel> GetDepartments();
        /// <summary>
        /// Gets detail of Specific employee by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        EmployeeDetailModal GetEmployeeById(int id);

        /// <summary>
        /// Insert the new employee 
        /// </summary>
        /// <param name="NewEmployee"></param>
        /// <returns></returns>
        EmployeeModel SaveEmployeee(EmployeeModel newEmployee);   

        /// <summary>
        /// Delete the Emplyee details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        bool DeleteEmployee(int id);


    }
}
