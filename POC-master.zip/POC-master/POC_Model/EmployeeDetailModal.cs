﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelEmployee
{
    /// <summary>
    /// Employee Details model
    /// </summary>
    public class EmployeeDetailModal
    {
        /// <summary>
        /// maps the employee details
        /// </summary>
        public EmployeeModel employeeModel { get; set; }
        /// <summary>
        /// Gets all the departments
        /// </summary>
        public IEnumerable<DepartmentModel> DepartmentList { get; set; }
        /// <summary>
        /// Maps all the Documents
        /// </summary>
        public IEnumerable<DocumentModel> DocumentList { get; set; }
    }
}
