﻿namespace ModelEmployee
{
    /// <summary>
    /// Maps with  Department entity
    /// </summary>
    public class DepartmentModel
    {
        /// <summary>
        ///Unique idendity of department
        /// </summary>
        public int DepartmentId { get; set; }

        /// <summary>
        /// Dercibes the Department by name
        /// </summary>
        public string DepartmentName { get; set; }
       
        
    }
}
