﻿using AutoMapper;
using BAL.Employees;
using Database.Employees;
using Database.Employees.DataAccess.UnitOfWork;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ModelEmployee;
using Moq;
using System.Collections.Generic;
using System.Linq;

namespace POC_Test
{
    /// <summary>
    /// Summary description for DepartmentUnitOfWorkTest
    /// </summary>
    [TestClass]
    public class EmployeeCordinatorTest
    {
        /// <summary>
        /// Gets or sets the test context which provides
        /// information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext { get; set; }
        /// <summary>
        ///  Mock Department unit of work for use in testing
        /// </summary>
        public IEmployeeCordinator employeeCordinator;
        /// <summary>
        ///  Mock Department unit of work for use in testing
        /// </summary>
        public IDepartmentUnitOfWork departmentUnitofWork;
        /// <summary>
        ///  Mock Document Unit OF work for use in testing
        /// </summary>
        public IDocumentUnitOfWork documentUnitOfWork;
        /// <summary>
        ///  Mock Employee Unit OF work for use in testing
        /// </summary>
        public IEmployeeUnitOfWork employeeUnitOfWork;

        #region Local objects
        /// <summary>
        /// Department 
        /// </summary>
        #region Department Objects
        /// <summary>
        /// Department Modal object to acces test method
        /// </summary>
        DepartmentModel depModel = new DepartmentModel
        {
            DepartmentId = 1,
            DepartmentName = "HR"
        };
        /// <summary>
        /// Department Modal  List object to acces test method
        /// </summary>
        IEnumerable<DepartmentModel> departmentModels = new List<DepartmentModel>
                {
                    new DepartmentModel { DepartmentId= 1, DepartmentName="IT" },
                    new DepartmentModel { DepartmentId= 1, DepartmentName="HR" }
                };
        #endregion
        /// <summary>
        /// Document Local Oaject
        /// </summary>
        #region Document Objects
        /// <summary>
        /// Document Modal object to acces test method
        /// </summary>
        DocumentModel docModel = new DocumentModel
        {
            DocumentTypeId = 1,
            DocumentTypeName = "HR"
        };
        /// <summary>
        /// Document Modal List object to acces test method
        /// </summary>
        IEnumerable<DocumentModel> doumentsModels = new List<DocumentModel>
                {
                    new DocumentModel { DocumentTypeId= 1, DocumentTypeName="Offer1" },
                    new DocumentModel { DocumentTypeId= 1, DocumentTypeName="Offer2" }
                };
        #endregion
        /// <summary>
        /// Employee Local Object
        /// </summary>
        #region Employee Objects
        /// <summary>
        /// Employee Modal object to acces test method
        /// </summary>
        EmployeeModel empModel = new EmployeeModel
        {
            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
            PAN = "ERRRF1485H",
            Salary = 10000
        };
        /// <summary>
        /// Employee Modal List object to acces test method
        /// </summary>
        IEnumerable<EmployeeModel> employeesModel = new List<EmployeeModel>
                {
                   new EmployeeModel
        {

            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
            PAN = "ERRRF1485H",
            Salary = 10000
        },
                   new EmployeeModel
        {

            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
            PAN = "ERRRF1485H",
            Salary = 10000
        },
                   new EmployeeModel
        {

            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
            PAN = "ERRRF1485H",
            Salary = 10000
        }
    };
        #endregion
        #endregion
        /// <summary>
        /// Initialization of mock for Dependencies
        /// </summary>
        #region Dependencies mock initialization
        Mock<IDepartmentUnitOfWork> mockDepartmentUnitofWork = new Mock<IDepartmentUnitOfWork>();
        Mock<IDocumentUnitOfWork> mockDocumentUnitofWork = new Mock<IDocumentUnitOfWork>();
        Mock<IEmployeeUnitOfWork> mockEmployeeUnitofWork = new Mock<IEmployeeUnitOfWork>();
        Mock<IMapper> mockImapper = new Mock<IMapper>();
        Mock<EmployeeContext> context = new Mock<EmployeeContext>();
        #endregion
        /// <summary>
        /// Test Initialization Method
        /// </summary>
        [TestInitialize]
        public void MyTestInitialize()
        {
            /// return all Departments
            mockDepartmentUnitofWork.Setup(dep => dep.GetDepartment()).Returns(departmentModels);
            ///return all Documents
            mockDocumentUnitofWork.Setup(doc => doc.GetDocuments()).Returns(doumentsModels);
            ///return all Employee
            mockEmployeeUnitofWork.Setup(emp => emp.GetEmployee()).Returns(employeesModel);
            ///return Employee by id
            mockEmployeeUnitofWork.Setup(emp => emp.GetEmployeeById(It.IsAny<int>())).Returns(empModel);
            ///Add the Employee
            mockEmployeeUnitofWork.Setup(emp => emp.SaveEmployeee(It.IsAny<EmployeeModel>())).Returns(empModel);
            ///Delete the Employee
            mockEmployeeUnitofWork.Setup(emp => emp.DeleteEmployee(It.IsAny<int>())).Returns(true);

            this.departmentUnitofWork = mockDepartmentUnitofWork.Object;
            this.documentUnitOfWork = mockDocumentUnitofWork.Object;
            this.employeeUnitOfWork = mockEmployeeUnitofWork.Object;
            this.employeeCordinator = new EmployeeCordinator(this.employeeUnitOfWork, this.departmentUnitofWork, this.documentUnitOfWork);
        }

        [TestMethod]
        public void GetEmployeeTest()
        {
            IEnumerable<EmployeeModel> testemployees = this.employeeCordinator.GetEmployee();
            Assert.IsNotNull(testemployees);
            Assert.AreEqual(3, testemployees.ToList().Count);

        }
        [TestMethod]
        public void GetDocumentTest()
        {
            IEnumerable<DocumentModel> testdocuments = this.employeeCordinator.GetDocuments();
            Assert.IsNotNull(testdocuments);
            Assert.AreEqual(2, testdocuments.ToList().Count);

        }
        [TestMethod]
        public void GetDepartmentTest()
        {
            IEnumerable<DepartmentModel> testdepartment = this.employeeCordinator.GetDepartments();
            Assert.IsNotNull(testdepartment);
            Assert.AreEqual(2, testdepartment.ToList().Count);

        }
        [TestMethod]
        public void GetEmployeeById()
        {
            var testemployeeresponse = this.employeeCordinator.GetEmployeeById(1);
            Assert.IsNotNull(testemployeeresponse);
        }
        [TestMethod]
        public void AddEmployee()
        {
            var isAdded = this.employeeCordinator.SaveEmployeee(empModel);
            Assert.IsNotNull(isAdded);
        }
        [TestMethod]
        public void DeleteEmployee()
        {
            bool isDeleted = this.employeeCordinator.DeleteEmployee(2);
            Assert.IsTrue(isDeleted);
        }
    }
}
