﻿using Api.Employees.Controllers;
using AutoMapper;
using BAL.Employees;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ModelEmployee;
using Moq;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Http;
using Contract.Employee;
using System.Web.Http.Results;
using System;

namespace POC_Test
{
    /// <summary>
    /// Summary description for DepartmentUnitOfWorkTest
    /// </summary>
    [TestClass]
    public class EmployeeControllerTest
    {
        /// <summary>
        /// Gets or sets the test context which provides
        /// information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext { get; set; }
        /// <summary>
        ///  Mock Employee Co-ordinator for use in testing
        /// </summary>
        public IEmployeeCordinator employeeCordinator;
        /// <summary>
        ///  Mock Employee Co-ordinator for use in testing
        /// </summary>
        public EmployessController employeeController;
        /// <summary>
        ///  Mock Imapper work for use in testing
        /// </summary>
        public IMapper mappers;

        #region Local objects
        /// <summary>
        /// Department 
        /// </summary>
        #region Department Objects
        /// <summary>
        /// Department response object to acces test method
        /// </summary>
        public DepartmentResponse depresponse = new DepartmentResponse
        {
            DepartmentId = 1,
            DepartmentName = "IT"
        };
        /// <summary>
        /// Department Model object to acces test method
        /// </summary>
        public DepartmentModel depModel = new DepartmentModel
        {
            DepartmentId = 1,
            DepartmentName = "HR"
        };
        /// <summary>
        /// Department response List object to acces test method
        /// </summary>
        IEnumerable<DepartmentResponse> departmentresponseList = new List<DepartmentResponse>
                {
                    new DepartmentResponse { DepartmentId= 1, DepartmentName="IT" },
                    new DepartmentResponse { DepartmentId= 1, DepartmentName="HR" }
                };
        /// <summary>
        /// Department model List object to acces test method
        /// </summary>
        IEnumerable<DepartmentModel> departmentModelList = new List<DepartmentModel>
                {
                    new DepartmentModel { DepartmentId= 1, DepartmentName="IT" },
                    new DepartmentModel { DepartmentId= 1, DepartmentName="HR" }
                };
        #endregion
        /// <summary>
        /// Document Local Oaject
        /// </summary>
        #region Document Objects
        /// <summary>
        /// document response  object to acces test method
        /// </summary>
        public DocumentResponse docresponse = new DocumentResponse
        {
            DocumentTypeId = 1,
            DocumentTypeName = "IT"
        };
        /// <summary>
        /// document modal object to acces test method
        /// </summary>
        public DocumentModel docModel = new DocumentModel
        {
            DocumentTypeId = 1,
            DocumentTypeName = "HR"
        };
        #endregion
        /// <summary>
        /// Employee Local Object
        /// </summary>
        #region Employee Objects
        /// <summary>
        /// employee response object to acces test method
        /// </summary>
        public EmployeeResponse empresponse = new EmployeeResponse
        {
            EmployeeId = 1,
            EmployeeName = "abcd",
            Documents = new DocumentResponse { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentResponse { DepartmentId = 1, DepartmentName = "IT" },
            //PAN = "ERRRF1485H",
            Salary = 15000
        };
        /// <summary>
        /// employee model object to acces test method
        /// </summary>
        public EmployeeModel empModel = new EmployeeModel
        {

            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
            PAN = "ERRRF1485H",
            Salary = 10000
        };
        /// <summary>
        /// employee response list object to acces test method
        /// </summary>
        IEnumerable<EmployeeResponse> employeesresponseList = new List<EmployeeResponse>
                {
                    new EmployeeResponse
        {
            EmployeeId = 1,
            EmployeeName = "abcd",
            Documents = new DocumentResponse { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentResponse { DepartmentId = 1, DepartmentName = "IT" },
            //PAN = "ERRRF1485H",
            Salary = 15000
        },
                    new EmployeeResponse
        {
            EmployeeId = 1,
            EmployeeName = "abcd",
            Documents = new DocumentResponse { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentResponse { DepartmentId = 1, DepartmentName = "IT" },
            //PAN = "ERRRF1485H",
            Salary = 15000
        },
        new EmployeeResponse
        {
            EmployeeId = 1,
            EmployeeName = "abcd",
            Documents = new DocumentResponse { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentResponse { DepartmentId = 1, DepartmentName = "IT" },
            //PAN = "ERRRF1485H",
            Salary = 15000
        },

    };
        /// <summary>
        /// employee model list object to acces test method
        /// </summary>
        IEnumerable<EmployeeModel> employeesModelList = new List<EmployeeModel>
                {
                   new EmployeeModel
        {

            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
            PAN = "ERRRF1485H",
            Salary = 10000
        },
                   new EmployeeModel
        {

            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
            PAN = "ERRRF1485H",
            Salary = 10000
        },
                   new EmployeeModel
        {

            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
            Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
            PAN = "ERRRF1485H",
            Salary = 10000
        }
    };
        /// <summary>
        /// employee detail modal object to acces test method
        /// </summary>
        EmployeeDetailModal employeeResponseModel = new EmployeeDetailModal
        {
            DepartmentList = new List<DepartmentModel>
            {
                 new DepartmentModel { DepartmentId= 1, DepartmentName="IT" },
                    new DepartmentModel { DepartmentId= 1, DepartmentName="HR" }
            },
            DocumentList = new List<DocumentModel>
            {
                 new DocumentModel { DocumentTypeId= 1, DocumentTypeName="Offer1" },
                    new DocumentModel { DocumentTypeId= 1, DocumentTypeName="Offer2" }
            },
            employeeModel = new EmployeeModel
            {

                EmployeeId = 1,
                EmployeeName = "abcd",
                DepartmentId = 1,
                DocumentTypeId = 1,
                Documents = new DocumentModel { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
                Departments = new DepartmentModel { DepartmentId = 1, DepartmentName = "IT" },
                PAN = "ERRRF1485H",
                Salary = 10000
            }
        };
        /// <summary>
        /// employee detail response object to acces test method
        /// </summary>
        EmployeeDetailResponse employeeResponseresponse = new EmployeeDetailResponse
        {
            DepartmentList = new List<DepartmentResponse>
            {
                 new DepartmentResponse { DepartmentId= 1, DepartmentName="IT" },
                    new DepartmentResponse { DepartmentId= 1, DepartmentName="HR" }
            },
            DocumentList = new List<DocumentResponse>
            {
                 new DocumentResponse { DocumentTypeId= 1, DocumentTypeName="Offer1" },
                    new DocumentResponse { DocumentTypeId= 1, DocumentTypeName="Offer2" }
            },
            EmployeeModel = new EmployeeResponse
            {

                EmployeeId = 1,
                EmployeeName = "abcd",
                Documents = new DocumentResponse { DocumentTypeId = 1, DocumentTypeName = "Offer1" },
                Departments = new DepartmentResponse { DepartmentId = 1, DepartmentName = "IT" },
                //PAN = "ERRRF1485H",
                Salary = 10000
            }
        };
        #endregion
        #endregion
        /// <summary>
        /// Initialization of mock for Dependencies
        /// </summary>
        #region Dependencies mock initialization
        Mock<IEmployeeCordinator> mockEmployeeCordinator = new Mock<IEmployeeCordinator>();
        Mock<IMapper> mockImapper = new Mock<IMapper>();
        #endregion
        /// <summary>
        /// Test Initialization Method
        /// </summary>
        [TestInitialize]
        public void MyTestInitialize()
        {
            ///return all employee
            mockEmployeeCordinator.Setup(emp => emp.GetEmployee()).Returns(employeesModelList);
            //return employee by id
            mockEmployeeCordinator.Setup(emp => emp.GetEmployeeById(It.IsAny<int>())).Returns(employeeResponseModel);
            //add or update employee
            mockEmployeeCordinator.Setup(emp => emp.SaveEmployeee(It.IsAny<EmployeeModel>())).Returns(empModel);
            //delete employee
            mockEmployeeCordinator.Setup(emp => emp.DeleteEmployee(It.IsAny<int>())).Returns(true);


            this.employeeCordinator = mockEmployeeCordinator.Object;
            this.mappers = mockImapper.Object;
            this.employeeController = new EmployessController(this.employeeCordinator, this.mappers);
            this.employeeController.Request = new HttpRequestMessage();
            this.employeeController.Configuration = new HttpConfiguration();
        }

        [TestMethod]
        [ExpectedException(typeof(AutoMapper.AutoMapperConfigurationException),
    "UnMApped Property Found")]
        public void GetEmployeeTest()
        {
            mockImapper.Setup(x => x.Map<IEnumerable<EmployeeResponse>>(employeesModelList)).Returns(employeesresponseList);
            var response = this.employeeController.GetEmployees();
            Assert.IsNotNull(response);
        }
        [TestMethod]
        [ExpectedException(typeof(AutoMapper.AutoMapperConfigurationException),
    "UnMApped Property Found")]
        public void GetEmployeeDetailsTest()
        {
            mockImapper.Setup(x => x.Map<EmployeeDetailResponse>(It.IsAny<EmployeeDetailModal>())).Returns(employeeResponseresponse);
            var response = this.employeeController.GetEmployeeDetails(1) as OkNegotiatedContentResult<EmployeeDetailResponse>;
            Assert.IsNotNull(response.Content);
        }
        [TestMethod]
        [ExpectedException(typeof(AutoMapper.AutoMapperConfigurationException),
    "UnMApped Property Found")]
        public void SaveEmployeeTest()
        {
            mockImapper.Setup(x => x.Map<EmployeeResponse>(It.IsAny<EmployeeModel>())).Returns(empresponse);
            mockImapper.Setup(x => x.Map<EmployeeModel>(It.IsAny<EmployeeResponse>())).Returns(empModel);
            var response = this.employeeController.SaveEmployee(empresponse) as OkNegotiatedContentResult<EmployeeResponse>;
            Assert.IsNotNull(response.Content);
        }
        [TestMethod]
        [ExpectedException(typeof(AutoMapper.AutoMapperConfigurationException),
    "UnMApped Property Found")]
        public void DeleteEmployeesTest()
        {
            var response = this.employeeController.DeleteEmployees(2) as OkNegotiatedContentResult<bool>;
            Assert.IsTrue(response.Content);
        }

    }
}
