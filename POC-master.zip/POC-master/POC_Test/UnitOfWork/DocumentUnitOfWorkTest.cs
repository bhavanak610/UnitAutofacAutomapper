﻿using AutoMapper;
using Database.Employees;
using Database.Employees.DataAccess.Repository;
using Database.Employees.DataAccess.UnitOfWork;
using DatabaseEntities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ModelEmployee;
using Moq;
using System.Collections.Generic;
using System.Linq;

namespace POC_Test
{
    /// <summary>
    /// Summary description for DocumentUnitOfWorkTest
    /// </summary>
    [TestClass]
    public class DocumentUnitOfWorkTest
    {
        /// <summary>
        /// Gets or sets the test context which provides
        /// information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext { get; set; }
        /// <summary>
        ///  Mock Employee Repository for use in testing
        /// </summary>
        public IDocumentTypeRepository documentTypeRepository;
        /// <summary>
        ///  Mock Employee UnitOF work for use in testing
        /// </summary>
        public IDocumentUnitOfWork documentUnitOfWork;
        /// <summary>
        ///  Mock Imapper work for use in testing
        /// </summary>
        public IMapper mappers;
        /// <summary>
        ///  Mock context work for use in testing
        /// </summary>
        public EmployeeContext dbcontext;
        /// <summary>
        /// Local object for mapping
        /// </summary>
        #region Local objects
        /// <summary>
        /// Document object to acces test method
        /// </summary>
        public DocumentType empEntities = new DocumentType
        {
           DocumentTypeId=1,
           DocumentTypeName="Offer1"
        };
        /// <summary>
        /// Document Modal object to acces test method
        /// </summary>
        public DocumentModel empModel = new DocumentModel
        {
            DocumentTypeId = 1,
            DocumentTypeName = "Offer1"
        };
        /// <summary>
        ///List Document object to acces test method
        /// </summary>
        IEnumerable<DocumentType> documnetEntities = new List<DocumentType>
                {
                    new DocumentType { DocumentTypeId= 1, DocumentTypeName="Offer1" },
                    new DocumentType { DocumentTypeId= 1, DocumentTypeName="Offer2" }
                };
        /// <summary>
        ///List Document Modal object to acces test method
        /// </summary>
        IEnumerable<DocumentModel> documentModels = new List<DocumentModel>
                {
                    new DocumentModel { DocumentTypeId= 1, DocumentTypeName="Offer1" },
                    new DocumentModel { DocumentTypeId= 1, DocumentTypeName="Offer2" }
                };
        #endregion
        /// <summary>
        /// Initialization of mock for Dependencies
        /// </summary>
        #region Dependencies mock initialization
        Mock<IDocumentTypeRepository> mockDocumentRepository = new Mock<IDocumentTypeRepository>();
        Mock<IMapper> mockImapper = new Mock<IMapper>();
        Mock<EmployeeContext> context = new Mock<EmployeeContext>();
        #endregion
        /// <summary>
        /// Test Initialization Method
        /// </summary>
        [TestInitialize]
        public void MyTestInitialize()
        {
            //return all the Document
            mockDocumentRepository.Setup(mr => mr.Get()).Returns(documnetEntities);          

            this.documentTypeRepository = mockDocumentRepository.Object;
            this.mappers = mockImapper.Object;
            this.dbcontext = context.Object;
            this.documentUnitOfWork = new DocumentUnitOfWork(this.documentTypeRepository, this.mappers, this.dbcontext);
        }        
        /// <summary>
        /// Get Doument test case method
        /// </summary>
        [TestMethod]
        public void GetDocumentsTest()
        {
            mockImapper.Setup(x => x.Map<IEnumerable<DocumentModel>>(documnetEntities)).Returns(documentModels);
            IEnumerable<DocumentModel> testdocuments = this.documentUnitOfWork.GetDocuments();
            Assert.IsNotNull(testdocuments);
            Assert.AreEqual(2, testdocuments.ToList().Count);

        }
    }
}
