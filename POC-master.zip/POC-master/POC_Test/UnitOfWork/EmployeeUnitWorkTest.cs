﻿using AutoMapper;
using Database.Employees;
using Database.Employees.DataAccess.Repository;
using Database.Employees.DataAccess.UnitOfWork;
using DatabaseEntities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ModelEmployee;
using Moq;
using System.Collections.Generic;
using System.Linq;

namespace POC_Test.UnitOfWork
{
    [TestClass]
    public class EmployeeUnitWorkTest
    {
        /// <summary>
        /// Gets or sets the test context which provides
        /// information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext { get; set; }
        /// <summary>
        ///  Mock Employee Repository for use in testing
        /// </summary>
        public IEmployeeRepository employeeRepository;
        /// <summary>
        ///  Mock Employee UnitOF work for use in testing
        /// </summary>
        public IEmployeeUnitOfWork employeeUnitOfWork;
        /// <summary>
        ///  Mock Imapper work for use in testing
        /// </summary>
        public IMapper mappers;
        /// <summary>
        ///  Mock context work for use in testing
        /// </summary>
        public EmployeeContext dbcontext;

        #region Local objects
        /// <summary>
        /// Employee object to acces test method
        /// </summary>
        public Employee empEntities = new Employee
        {
            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            PAN = "ERRRF1485H",
            Salary = 15000
        };
        /// <summary>
        /// Employee  Modal object to acces test method
        /// </summary>
        public EmployeeModel empModel = new EmployeeModel
        {

            EmployeeId = 1,
            EmployeeName = "abcd",
            DepartmentId = 1,
            DocumentTypeId = 1,
            PAN = "ERRRF1485H",
            Salary = 10000
        };
        /// <summary>
        /// Employee List object to acces test method
        /// </summary>
        IEnumerable<Employee> employeesEntities = new List<Employee>
                {
                    new Employee { EmployeeId = 1, EmployeeName = "abcd",
                        DepartmentId = 1, DocumentTypeId=1,PAN="ERRRF1485H"},
                    new Employee { EmployeeId = 2, EmployeeName = "VVVV",
                        DepartmentId = 1, DocumentTypeId=1,PAN="ERRRF1485H"},
                    new Employee { EmployeeId = 3, EmployeeName = "GGG",
                        DepartmentId = 1, DocumentTypeId=1,PAN="ERRRF1485H"}

                };
        /// <summary>
        /// Employee Modal List object to acces test method
        /// </summary>
        IEnumerable<EmployeeModel> employeesModel = new List<EmployeeModel>
                {
                    new EmployeeModel { EmployeeId = 1, EmployeeName = "abcd",
                        DepartmentId = 1, DocumentTypeId=1,PAN="ERRRF1485H"
                    },
                    new EmployeeModel { EmployeeId = 2, EmployeeName = "VVVV",
                        DepartmentId = 1, DocumentTypeId=1,PAN="ERRRF1485H"
                    },
                    new EmployeeModel { EmployeeId = 3, EmployeeName = "GGG",
                        DepartmentId = 1, DocumentTypeId=1,PAN="ERRRF1485H"
                    }

                };
        #endregion
        /// <summary>
        /// Initialization of mock for Dependencies
        /// </summary>
        #region Dependencies mock initialization
        Mock<IEmployeeRepository> mockemployeeRepository = new Mock<IEmployeeRepository>();
        Mock<IMapper> mockImapper = new Mock<IMapper>();
        Mock<EmployeeContext> context = new Mock<EmployeeContext>();
        #endregion
        /// <summary>
        /// Test Initialization Method
        /// </summary>
        [TestInitialize]
        public void MyTestInitialize()
        {
            //return all employees
            mockemployeeRepository.Setup(mr => mr.Get()).Returns(employeesEntities);

            // return a employee by Id
            mockemployeeRepository.Setup(mr => mr.GetById(
                It.IsAny<int>())).Returns((int i) => employeesEntities.Where(
                x => x.EmployeeId == i).Single());

            // Allows us to test saving a employee
            mockemployeeRepository.Setup(mr => mr.Insert(It.IsAny<Employee>()));

            this.employeeRepository = mockemployeeRepository.Object;
            this.mappers = mockImapper.Object;
            this.dbcontext = context.Object;
            this.employeeUnitOfWork = new EmployeeUnitOfWork(this.employeeRepository, this.mappers, this.dbcontext);
        }
        /// <summary>
        /// return all Employee
        /// </summary>
        [TestMethod]
        public void GetEmployeeTest()
        {
            mockImapper.Setup(x => x.Map<IEnumerable<EmployeeModel>>(employeesEntities)).Returns(employeesModel);
            IEnumerable<EmployeeModel> testemployees = this.employeeUnitOfWork.GetEmployee();
            Assert.IsNotNull(testemployees);
            Assert.AreEqual(3, testemployees.ToList().Count);
        }
        /// <summary>
        /// return employee by id
        /// </summary>        
        [TestMethod]
        public void GetEmployeeByIdTest()
        {
            mockImapper.Setup(x => x.Map<EmployeeModel>(It.IsAny<Employee>())).Returns(empModel);
            EmployeeModel testemployees = this.employeeUnitOfWork.GetEmployeeById(1);
            Assert.IsNotNull(testemployees);
        }
        /// <summary>
        ///add employee
        /// </summary>        
        [TestMethod]
        public void AddEmployeeeTest()
        {
            mockImapper.Setup(x => x.Map<EmployeeModel>(It.IsAny<Employee>())).Returns(empModel);
            mockImapper.Setup(x => x.Map<Employee>(It.IsAny<EmployeeModel>())).Returns(empEntities);
            var isAdded = this.employeeUnitOfWork.SaveEmployeee(empModel);
            Assert.IsNotNull(isAdded);
        }
        
        [TestMethod]
        public void DeletedEmployee()
        {
            bool isDeleted = this.employeeUnitOfWork.DeleteEmployee(2);
            Assert.IsTrue(isDeleted);
        }

    }
}
