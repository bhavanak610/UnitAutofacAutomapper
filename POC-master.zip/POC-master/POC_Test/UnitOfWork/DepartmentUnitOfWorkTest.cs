﻿using AutoMapper;
using Database.Employees;
using Database.Employees.DataAccess.Repository;
using Database.Employees.DataAccess.UnitOfWork;
using DatabaseEntities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ModelEmployee;
using Moq;
using System.Collections.Generic;
using System.Linq;

namespace POC_Test
{
    /// <summary>
    /// Summary description for DepartmentUnitOfWorkTest
    /// </summary>
    [TestClass]
    public class DepartmentUnitOfWorkTest
    {
        /// <summary>
        /// Gets or sets the test context which provides
        /// information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext { get; set; }
        /// <summary>
        ///  Mock Employee Repository for use in testing
        /// </summary>
        public IDepartmentRepository departmentRepository;
        /// <summary>
        ///  Mock Employee UnitOF work for use in testing
        /// </summary>
        public IDepartmentUnitOfWork departmentUnitOfWork;
        /// <summary>
        ///  Mock Imapper work for use in testing
        /// </summary>
        public IMapper mappers;
        /// <summary>
        ///  Mock context work for use in testing
        /// </summary>
        public EmployeeContext dbcontext;

        #region Local objects
        /// <summary>
        /// Department object to acces test method
        /// </summary>
        public Department empEntities = new Department
        {
            DepartmentId = 1,
            DepartmentName = "IT"
        };
        /// <summary>
        /// Department modal object to acces test method
        /// </summary>
        public DepartmentModel empModel = new DepartmentModel
        {
            DepartmentId = 1,
            DepartmentName = "HR"
        };
        /// <summary>
        /// Department List object to acces test method
        /// </summary>
        IEnumerable<Department> departmentEntities = new List<Department>
                {
                    new Department { DepartmentId= 1, DepartmentName="IT" },
                    new Department { DepartmentId= 1, DepartmentName="HR" }
                };
        /// <summary>
        /// Department Modal list object to acces test method
        /// </summary>
        IEnumerable<DepartmentModel> departmentModels = new List<DepartmentModel>
                {
                    new DepartmentModel { DepartmentId= 1, DepartmentName="IT" },
                    new DepartmentModel { DepartmentId= 1, DepartmentName="HR" }
                };
        #endregion
        /// <summary>
        /// Initialization of mock for Dependencies
        /// </summary>
        #region Dependencies mock initialization
        Mock<IDepartmentRepository> mockDepartmentRepository = new Mock<IDepartmentRepository>();
        Mock<IMapper> mockImapper = new Mock<IMapper>();
        Mock<EmployeeContext> context = new Mock<EmployeeContext>();
        #endregion
        /// <summary>
        /// Test Initialization Method
        /// </summary>
        [TestInitialize]
        public void MyTestInitialize()
        {
            //retun all the Department
            mockDepartmentRepository.Setup(mr => mr.Get()).Returns(departmentEntities);

            this.departmentRepository = mockDepartmentRepository.Object;
            this.mappers = mockImapper.Object;
            this.dbcontext = context.Object;
            this.departmentUnitOfWork = new DepartmentUnitOfWork(this.departmentRepository, this.mappers, this.dbcontext);
        }

        [TestMethod]
        public void GetDepartmentTest()
        {
            mockImapper.Setup(x => x.Map<IEnumerable<DepartmentModel>>(departmentEntities)).Returns(departmentModels);
            IEnumerable<DepartmentModel> testDepartments = this.departmentUnitOfWork.GetDepartment();
            Assert.IsNotNull(testDepartments);
            Assert.AreEqual(2, testDepartments.ToList().Count);

        }
    }
}
