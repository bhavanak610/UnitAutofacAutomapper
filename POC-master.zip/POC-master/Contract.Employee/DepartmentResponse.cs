﻿namespace Contract.Employee
{
    /// <summary>
    /// Maps with  Department Model
    /// </summary>
    public class DepartmentResponse
    {
        /// <summary>
        ///Unique idendity of department
        /// </summary>
        public int DepartmentId { get; set; }
        /// <summary>
        /// Dercibes the Department by name
        /// </summary>
        public string DepartmentName { get; set; }
                
    }
}
