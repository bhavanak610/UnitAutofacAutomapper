﻿namespace Contract.Employee
{
    /// <summary>
    /// Specifies Documents and maps with Document Type table
    /// </summary>
    public class DocumentResponse
    {
        /// <summary>
        /// Unique Identity for Documnets
        /// </summary>
        public int DocumentTypeId { get; set; }
        /// <summary>
        /// Describe Documents by Name
        /// </summary>
        public string DocumentTypeName { get; set; }

    }
}
