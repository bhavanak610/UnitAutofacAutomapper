﻿namespace Contract.Employee
{
    /// <summary>
    /// Maps to all the emplyee dependencies and Model of Employee
    /// </summary>
    public class EmployeeResponse
    {
        /// <summary>
        /// Unique Identity for Employee
        /// </summary>
        public int EmployeeId { get; set; }
        /// <summary>
        /// Describe Employee by Name
        /// </summary>
        public string EmployeeName { get; set; }
        /// <summary>
        /// Pan number of Employee
        /// </summary>
        // public string PAN { get; set; }
        /// <summary>
        /// Adhhar number of Employee
        /// </summary>
        public string AddharNo { get; set; }
        /// <summary>
        /// Salary of Employee
        /// </summary>
        public decimal Salary { get; set; }
        /// <summary>
        /// Grade of Employee
        /// </summary>
        public Grade GradeStar { get; set; }

        /// <summary>
        ///  Corresponding Department of employee
        /// </summary>
        public DepartmentResponse Departments { get; set; }
        /// <summary>
        ///  Corresponding Document of employee
        /// </summary>
        public DocumentResponse Documents { get; set; }

    }
}

