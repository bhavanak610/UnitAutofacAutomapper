﻿using System.Collections.Generic;

namespace Contract.Employee
{
    /// <summary>
    /// Employee Editable model with options
    /// </summary>
    public class EmployeeDetailResponse
    {
        /// <summary>
        /// maps the employee details
        /// </summary>
        public EmployeeResponse EmployeeModel { get; set; }
        /// <summary>
        /// Gets all the departments
        /// </summary>
        public IEnumerable<DepartmentResponse> DepartmentList { get; set; }
        /// <summary>
        /// Maps all the Documents
        /// </summary>
        public IEnumerable<DocumentResponse> DocumentList { get; set; }
    }
}
