﻿namespace Contract.Employee
{    /// <summary>
     /// Enum of Grade of Employee
     /// </summary>
    public enum Grade
    {
        /// <summary>
        /// To state salary less than 10000
        /// </summary>
        star2 = 2,
        /// <summary>
        /// ToSattae salary greatedr than 10000
        /// </summary>
        star3
    }
}
