namespace Database.Employees
{
    using System;
    using System.Data.Entity;
    using System.Linq;

    public class EmployeeContext : DbContext
    {       
        public EmployeeContext()
            : base("name=EmployeeContext")
        {
            Database.SetInitializer<EmployeeContext>(null);
        }        
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        { 
            modelBuilder.Configurations.Add(new DepartmentMap());
            modelBuilder.Configurations.Add(new EmployeeMap());
            modelBuilder.Configurations.Add(new DocumentTypeMap());
        }        
    }    
}