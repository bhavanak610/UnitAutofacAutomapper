﻿using DatabaseEntities;
using System.Data.Entity.ModelConfiguration;

namespace Database.Employees
{
    /// <summary>
    /// Department Map configuration to Department table
    /// </summary>
    public class DepartmentMap : EntityTypeConfiguration<Department>
    {
        /// <summary>
        /// Mapping configuration to table Department
        /// </summary>
        public DepartmentMap()
        {
            /// <summary>
            /// Primary key
            /// </summary>
            HasKey(e => e.DepartmentId);
            this.Property(e => e.DepartmentName).HasColumnName("DepartmentName");
            this.ToTable("Department");
           

        }
       
    }
}
