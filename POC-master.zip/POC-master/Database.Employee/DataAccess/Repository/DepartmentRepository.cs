﻿using DatabaseEntities;

namespace Database.Employees.DataAccess.Repository
{
    /// <summary>
    /// Department Repository to execute all the DB operations
    /// </summary>
    public interface IDepartmentRepository:IRepository<Department>
    {
    }
    /// <summary>
    /// Department Repository to execute all the DB operations
    /// </summary>
    public class DepartmentRepository:Repository<Department>,IDepartmentRepository
    {
        /// <summary>
        /// Context Reference
        /// </summary>
        private readonly EmployeeContext _context;

        /// <summary>
        /// Initialize dbContext
        /// </summary>
        /// <param name="context"></param>
        public DepartmentRepository(EmployeeContext context):base(context)
        {
            _context = context;
        }
    }
}
