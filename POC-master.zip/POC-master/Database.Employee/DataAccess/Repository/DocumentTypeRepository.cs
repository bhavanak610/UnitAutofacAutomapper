﻿using DatabaseEntities;

namespace Database.Employees.DataAccess.Repository
{
    /// <summary>
    /// Document Repository to execute all the DB operations
    /// </summary>
    public interface IDocumentTypeRepository : IRepository<DocumentType>
    {
    }
    /// <summary>
    /// Document Repository to execute all the DB operations
    /// </summary>
    public class DocumentTypeRepository : Repository<DocumentType>, IDocumentTypeRepository
    {
        /// <summary>
        /// Context Reference
        /// </summary>
        private readonly EmployeeContext _context;

        /// <summary>
        /// Initialize dbContext
        /// </summary>
        /// <param name="context"></param>
        public DocumentTypeRepository(EmployeeContext context) : base(context)
        {
            _context = context;
        }
    }
    
}
