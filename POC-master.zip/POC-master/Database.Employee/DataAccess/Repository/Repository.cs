﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace Database.Employees.DataAccess.Repository
{
    /// <summary>
    /// Generic Repository to Perform Database operations
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class Repository<T> : IRepository<T> where T : class
    {
        /// <summary>
        /// DBContext to Access DBset and operations
        /// </summary>
        internal EmployeeContext context;
        /// <summary>
        /// generic DBset to acces operations
        /// </summary>
        internal DbSet<T> dbSet;

        /// <summary>
        /// Initializes thecontext and dbset for operations
        /// </summary>
        /// <param name="context"></param>
        public Repository(EmployeeContext context)
        {
            this.context = context;
            this.dbSet = context.Set<T>();
        }

        /// <summary>
        /// Return all the rows in collection
        /// </summary>
        /// <returns></returns>
        public virtual IEnumerable<T> Get()
        {
            return dbSet.ToList();
        }

        /// <summary>
        /// Returns data for specific Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual T GetById(int id)
        {
            return dbSet.Find(id);
        }

        /// <summary>
        /// Add new record
        /// </summary>
        /// <param name="entity"></param>
        public virtual T Insert(T entity)
        {
            return dbSet.Add(entity);

        }

        /// <summary>
        /// Dletes the record by id
        /// </summary>
        /// <param name="id"></param>
        public virtual void Delete(int id)
        {
            T entityToDelete = dbSet.Find(id);
            if (context.Entry(entityToDelete).State == EntityState.Detached)
            {
                dbSet.Attach(entityToDelete);
            }
            dbSet.Remove(entityToDelete);
        }

        /// <summary>
        /// update the whole entity in database
        /// </summary>
        /// <param name="entity"></param>
        public virtual T Update(T entity)
        {
            context.Entry(entity).State = EntityState.Modified;
            return dbSet.Attach(entity);
        }
    }
}
