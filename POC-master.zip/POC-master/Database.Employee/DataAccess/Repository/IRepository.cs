﻿using System.Collections.Generic;

namespace Database.Employees.DataAccess.Repository
{
    /// <summary>
    /// Generic Repository to Perform Database operations
    /// </summary>
    public interface IRepository<T> where T : class
    {
        /// <summary>
        /// Get Specific row data from ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>T</returns>
        T GetById(int id);
        /// <summary>
        /// Get Specific all rows from Database
        /// </summary>
        /// <returns> IEnumerable<T></returns>
        IEnumerable<T> Get();
        /// <summary>
        /// Insert the entity in Table
        /// </summary>
        /// <param name="entity"></param>
        /// <returns> T </returns>
        T Insert(T entity);
        /// <summary>
        /// Perform Delete opeartion depending on ID
        /// </summary>
        /// <param name="id"></param>        
        void Delete(int id);
        /// <summary>
        /// Update the Entity 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns> T </returns>
        T Update(T entity);
    }
}
