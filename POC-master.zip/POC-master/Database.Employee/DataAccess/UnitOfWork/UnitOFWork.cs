﻿using System.Data.Entity;

namespace Database.Employees.DataAccess.UnitOfWork
{
    /// <summary>
    /// Unit of Work Generic base for inherit by required artifact
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class UnitOfWork<T> : IUnitOfWork where T : DbContext
    {
        /// <summary>
        ///Reference of DBContext
        /// </summary>
        private readonly T _context;

        /// <summary>
        /// Initializes the Context for Unit of Work operations 
        /// </summary>
        /// <param name="context"></param>
        public UnitOfWork(T context)
        {
            _context = context;
        }

        /// <summary>
        /// Save method of unity of work to save context changes
        /// </summary>
        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
