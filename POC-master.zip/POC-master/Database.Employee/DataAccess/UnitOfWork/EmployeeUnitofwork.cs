﻿using AutoMapper;
using Database.Employees.DataAccess.Repository;
using DatabaseEntities;
using ModelEmployee;
using System;
using System.Collections.Generic;

namespace Database.Employees.DataAccess.UnitOfWork
{
    /// <summary>
    /// Employee unit of work  function declaration
    /// </summary>
    public interface IEmployeeUnitOfWork
    {
        /// <summary>
        /// Gets all the Employee details
        /// </summary>
        /// <returns> IEnumerable<EmployeeModel></returns>
        IEnumerable<EmployeeModel> GetEmployee();

        /// <summary>
        /// Gets detail of Specific employee by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>EmployeeModel</returns>
        EmployeeModel GetEmployeeById(int id);

        /// <summary>
        /// Insert the new employee 
        /// </summary>
        /// <param name="NewEmployee"></param>
        /// <returns>EmployeeModel</returns>
        EmployeeModel SaveEmployeee(EmployeeModel NewEmployee);

        /// <summary>
        /// Delete the Emplyee details
        /// </summary>
        /// <param name="id"></param>
        /// <returns>bool</returns>
        bool DeleteEmployee(int id);
    }
    /// <summary>
    /// Employee unit of work to declarartion 
    /// </summary>
    public class EmployeeUnitOfWork : UnitOfWork<EmployeeContext>, IEmployeeUnitOfWork
    {
        /// <summary>
        /// Reference for Employee Repository
        /// </summary>
        private readonly IEmployeeRepository empRespository;
        /// <summary>
        /// Mapping reference
        /// </summary>
        private readonly IMapper mapper;
        /// <summary>
        /// initialize EmployeeRepository and Context
        /// </summary>
        /// <param name="empRespository"></param>
        /// /// <param name="mapper"></param>
        /// <param name="context"></param>
        public EmployeeUnitOfWork(IEmployeeRepository empRespository, IMapper mapper, EmployeeContext context) :
            base(context)
        {
            this.empRespository = empRespository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Gets all the Employee details
        /// </summary>
        /// <returns>IEnumerable<EmployeeModel></returns>
        public IEnumerable<EmployeeModel> GetEmployee()
        {
            var result = empRespository.Get();
            IEnumerable<EmployeeModel> resultmodel = mapper.Map<IEnumerable<EmployeeModel>>(result);
            return resultmodel;
        }

        /// <summary>
        /// Gets detail of Specific employee by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>EmployeeModel</returns>
        public EmployeeModel GetEmployeeById(int id)
        {
            var result = empRespository.GetById(id);
            EmployeeModel resultmodel = mapper.Map<EmployeeModel>(result);
            return resultmodel;
        }
        /// <summary>
        /// Insert the new emplyee 
        /// </summary>
        /// <param name="NewEmployee"></param>
        /// <returns></returns>
        public EmployeeModel SaveEmployeee(EmployeeModel NewEmployee)
        {
            if (NewEmployee.EmployeeId > 0)
            {
                var result = empRespository.Update(mapper.Map<Employee>(NewEmployee));
                Save();
                return mapper.Map<EmployeeModel>(result);
            }
            else
            {
                var result = empRespository.Insert(mapper.Map<Employee>(NewEmployee));
                Save();
                return mapper.Map<EmployeeModel>(result);
            }

        }
        /// <summary>
        /// Delete the Emplyee details
        /// </summary>
        /// <param name="id"></param>
        /// <returns>bool</returns>
        public bool DeleteEmployee(int id)
        {
            try
            {
                empRespository.Delete(id);
                Save();
                return true;
            }
            catch (Exception e)
            {
                //Log into logger
                return false;
            }
        }


    }
}
