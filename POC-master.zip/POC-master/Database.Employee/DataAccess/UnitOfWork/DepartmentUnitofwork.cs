﻿using AutoMapper;
using Database.Employees.DataAccess.Repository;
using ModelEmployee;
using System.Collections.Generic;

namespace Database.Employees.DataAccess.UnitOfWork
{
    public interface IDepartmentUnitOfWork
    {
        /// <summary>
        /// Get List of Departments
        /// </summary>
        /// <returns></returns>
        IEnumerable<DepartmentModel> GetDepartment();
        
    }
    public class DepartmentUnitOfWork : UnitOfWork<EmployeeContext>, IDepartmentUnitOfWork
    {
        /// <summary>
        /// Refenrence for Department Repository
        /// </summary>
        private readonly IDepartmentRepository depRespository;
        /// <summary>
        /// Mapping reference
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// Initialize Context and Department Repository
        /// </summary>
        /// <param name="depRespository"></param>
        /// <param name="context"></param>
        public DepartmentUnitOfWork(IDepartmentRepository depRespository, IMapper mapper,EmployeeContext context) :
            base(context)
        {
            this.depRespository = depRespository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Get all the department
        /// </summary>
        /// <returns></returns>
        public IEnumerable<DepartmentModel> GetDepartment()
        {
            var result = depRespository.Get();
            return mapper.Map<IEnumerable<DepartmentModel>>(result);
        }      


    }
}
