﻿using AutoMapper;
using Database.Employees.DataAccess.Repository;
using ModelEmployee;
using System.Collections.Generic;

namespace Database.Employees.DataAccess.UnitOfWork
{
    /// <summary>
    /// Document unit of work function declaration
    /// </summary>
    public interface IDocumentUnitOfWork
    {
        /// <summary>
        /// Get list of Documents
        /// </summary>
        /// <returns></returns>
        IEnumerable<DocumentModel> GetDocuments();

    }
    /// <summary>
    /// Document unit of work function definition
    /// </summary>
    public class DocumentUnitOfWork : UnitOfWork<EmployeeContext>, IDocumentUnitOfWork
    {
        /// <summary>
        /// Reference for Document repository
        /// </summary>
        private readonly IDocumentTypeRepository docRespository;
        /// <summary>
        /// Mapping reference
        /// </summary>
        private readonly IMapper mapper;
        /// <summary>
        ///Instantiate the Document repository and Context
        /// </summary>
        public DocumentUnitOfWork(IDocumentTypeRepository docRespository, IMapper mapper, EmployeeContext context) :
            base(context)
        {
            this.docRespository = docRespository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Get list of Documents
        /// </summary>
        /// <returns></returns>
        public IEnumerable<DocumentModel> GetDocuments()
        {
            var result = docRespository.Get();
            return  mapper.Map<IEnumerable<DocumentModel>>(result);
        }


    }
}
