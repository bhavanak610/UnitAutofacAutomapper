﻿namespace Database.Employees.DataAccess.UnitOfWork
{
    /// <summary>
    /// Unit of work functions
    /// </summary>
    public interface IUnitOfWork
    {
        /// <summary>
        /// Save method of unity of work to save context changes
        /// </summary>
        void Save();

    }
}