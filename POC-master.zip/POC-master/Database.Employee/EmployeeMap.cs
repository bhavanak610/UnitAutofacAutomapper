﻿using DatabaseEntities;
using System.Data.Entity.ModelConfiguration;

namespace Database.Employees
{
    /// <summary>
    /// Employee Map configuration to employee table
    /// </summary>
    public class EmployeeMap : EntityTypeConfiguration<Employee>
    {
        /// <summary>
        /// Mapping configuration to table Employee
        /// </summary>
        public EmployeeMap()
        {
            /// <summary>
            /// Primary key
            /// </summary>
            HasKey(e => e.EmployeeId);

            this.Property(e => e.EmployeeName).HasColumnName("EmployeeName");
            this.Property(e => e.PAN).HasColumnName("PAN");
            this.Property(e => e.AddharNo).HasColumnName("AddharNo");
            this.Property(e => e.Salary).HasColumnName("Salary");
            this.Property(e => e.DepartmentId).HasColumnName("DepartmentId");
            this.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeId");
            this.ToTable("Employee");

            /// <summary>
            /// Foreign Key
            /// </summary>
            HasRequired(p => p.Documents)
           .WithMany()
           .HasForeignKey(p => p.DocumentTypeId)
           .WillCascadeOnDelete(false);

            /// <summary>
            /// Foreign Key
            /// </summary>
            HasRequired(p => p.Departments)
           .WithMany()
           .HasForeignKey(p => p.DepartmentId)
           .WillCascadeOnDelete(false);
        }
    }
}
