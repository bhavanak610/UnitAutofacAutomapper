﻿using DatabaseEntities;
using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database.Employees
{
    /// <summary>
    /// Document Map configuration to DocumentType table
    /// </summary>
    public class DocumentTypeMap : EntityTypeConfiguration<DocumentType>
    {
        /// <summary>
        /// Mapping configuration to table DocumentType
        /// </summary>
        public DocumentTypeMap()
        {
            /// <summary>
            /// Primary key
            /// </summary>
            HasKey(e => e.DocumentTypeId);

            this.Property(e => e.DocumentTypeName).HasColumnName("DocumentTypeName");
            this.ToTable("DocumentType");             
        }      
    }
}
