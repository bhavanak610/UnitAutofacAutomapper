﻿using System;

namespace EmployeeeContract
{
    public class Class1
    {
    }
}
