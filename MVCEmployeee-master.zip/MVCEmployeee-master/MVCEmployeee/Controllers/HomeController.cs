﻿using MVCEmployeee.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace MVCEmployeee.Controllers
{
    public class HomeController : BaseController
    {
        #region Employee 
        /// <summary>
        /// Retuen the List of Employee Details View
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            var empList = GetAsync<List<EmployeeViewModel>>("Employees", string.Empty);
            return View(empList);
        }
        /// <summary>
        /// Retuen Employee Details to Edit View
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("Edit/{id}")]
        public ActionResult EmployeeEdit(int id)
        {            
           var employeeView = GetAsync<EmployeeResponseModal>("Employee/", Convert.ToString(id));
            if (employeeView.EmployeeModel == null)
            {
                employeeView.EmployeeModel = new EmployeeViewModel();
            }
            return PartialView("_EmployeeEdit", employeeView);
        }
        /// <summary>
        /// Returns Flag after deleting the EmployeeDetails
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("EmployeeDeactivate/{id}")]
        public ActionResult Deactivate(int id)
        {
            bool IsDeactivated = PostAsync<EmployeeViewModel>("Employee/deactivate/", Convert.ToString(id), null);
            return Json(IsDeactivated, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// Saves the EmployeeDetails
        /// </summary>
        /// <param name="emp"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult SaveEdit(EmployeeResponseModal emp, int id = 0)
        {
            bool IsSaved = PostAsync("EmployeePost/", Convert.ToString(id), emp.EmployeeModel);
            return Json(IsSaved);
        }
        #endregion

    }


}
