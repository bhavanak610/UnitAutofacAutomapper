﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Web.Mvc;

namespace MVCEmployeee.Controllers
{
    public class BaseController : Controller
    {
        /// <summary>
        /// Generic Client Get Call
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="url"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        protected T GetAsync<T>(string url, string param) where T:new ()
        {
            T employeeView=new T();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:44315/");
                //HTTP GET                
                var responseTask = client.GetAsync(url + param);
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<T>();
                    readTask.Wait();

                    employeeView = readTask.Result;                    
                }
                else //web api sent error response 
                {
                    //log response status here..                    

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }

            }
            return employeeView;
        }
       /// <summary>
       /// Generic Client Post call
       /// </summary>
       /// <typeparam name="T"></typeparam>
       /// <param name="url"></param>
       /// <param name="param"></param>
       /// <param name="model"></param>
       /// <returns></returns>
        protected bool PostAsync<T>(string url, string param, T model) where T : class
        {
            T employeeView = model;
            bool isSaved;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:44315/");
                //HTTP POST
                var httpContent = new StringContent(JsonConvert.SerializeObject(employeeView), Encoding.UTF8, "application/json");
                var responseTask = client.PostAsync(url + param, httpContent);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    isSaved = Convert.ToBoolean(readTask.Result);
                }
                else //web api sent error response 
                {
                    //log response status here..

                    isSaved = false;

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }

            }
            return isSaved;
        }
    }
}
