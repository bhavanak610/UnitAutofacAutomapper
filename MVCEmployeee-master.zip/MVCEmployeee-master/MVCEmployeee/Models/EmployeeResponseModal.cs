﻿using System.Collections.Generic;

namespace MVCEmployeee.Models
{
    /// <summary>
    /// Model to bind Employee Edit view
    /// </summary>
    public class EmployeeResponseModal
    {
        /// <summary>
        /// maps the employee details
        /// </summary>
        public EmployeeViewModel EmployeeModel { get; set; }
        /// <summary>
        /// Gets all the departments
        /// </summary>
        public List<DepartmentViewModel> DepartmentList { get; set; }
        /// <summary>
        /// Maps all the Documents
        /// </summary>
        public List<DocumentViewModel> DocumentList { get; set; }
        public EmployeeResponseModal()
        {
            this.EmployeeModel = new EmployeeViewModel();
        }
    }
}