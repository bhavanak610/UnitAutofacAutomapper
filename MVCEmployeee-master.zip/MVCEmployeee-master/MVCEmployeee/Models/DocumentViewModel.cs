﻿namespace MVCEmployeee.Models
{
    /// <summary>
    /// Model to bind Document dropdown
    /// </summary>
    public class DocumentViewModel
    {
        /// <summary>
        /// Unique Document Id
        /// </summary>
        public int DocumentTypeId { get; set; }
        /// <summary>
        /// Name of Document
        /// </summary>
        public string DocumentTypeName { get; set; }
      
    }
}