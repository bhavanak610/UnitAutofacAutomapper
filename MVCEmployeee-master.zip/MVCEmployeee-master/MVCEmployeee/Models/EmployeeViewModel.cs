﻿namespace MVCEmployeee.Models
{
    /// <summary>
    /// Model to bind with employee view
    /// </summary>
    public class EmployeeViewModel
    {
        /// <summary>
        /// Unique employee id
        /// </summary>
        public int EmployeeID { get; set; }
        /// <summary>
        /// Name of employee
        /// </summary>
        public string EmployeeName { get; set; }
        /// <summary>
        /// Pan card number
        /// </summary>
        public string PAN { get; set; }
        /// <summary>
        /// unique addhar number
        /// </summary>
        public string AddharNo { get; set; }
        /// <summary>
        /// salary of employee
        /// </summary>
        public decimal Salary { get; set; }
        /// <summary>
        /// Grade of Employee
        /// </summary>
        public Grade GradeStar { get; set; }
        /// <summary>
        /// Coresponding Department of employee
        /// </summary>
        public DepartmentViewModel Departments { get; set; }
        /// <summary>
        /// Coresponding Document of Employee
        /// </summary>
        public DocumentViewModel Documents { get; set; }
    }   
}