﻿namespace MVCEmployeee.Models
{
    /// <summary>
    /// Model to bind Department Dropdown
    /// </summary>
    public class DepartmentViewModel
    {
        /// <summary>
        /// Unique Department Id
        /// </summary>
        public int DepartmentId { get; set; }
        /// <summary>
        /// Name of Department
        /// </summary>
        public string DepartmentName { get; set; }
               
    }
}